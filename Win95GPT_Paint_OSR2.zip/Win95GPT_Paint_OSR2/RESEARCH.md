# Evidence and provenance

## The supplied build

The attachment contains MSPAINT.EXE (311,808 bytes), MSPAINT.HLP, and four MFC DLLs. All six archive entries carry August 24, 1996 timestamps. The executable is an x86 Win32 GUI PE, with English resource language 0x0409 and an embedded file/product version string of **4.00.950**. This identifies the target more precisely than assuming the application version matches the OSR2 operating system build number. The supplied archive is labeled OSR2. Its label is not independent proof of media provenance.

The executable SHA-256 is `86fc83f836b745566df3c509b7210f1201e2b6bb2e09367260e7cdc800186d55`. The unchanged supplied ZIP and component hashes are in reference/build.json. The archive contains the application and supporting files. Use a separately available English OSR2 installation to observe the original system dialogs, GDI, fonts, and integrations.

| Evidence in the package | What was checked |
|---|---|
| resource-index.json | A static PE resource walk found 21 bitmaps, six menus, seven dialogs, three accelerator tables, 44 string-table blocks, 15 cursor groups, six icon groups, and a version resource. Hashes identify each resource payload. |
| menus.json, accelerators.json, shortcuts.csv, strings.json | The first two preserve the original numeric IDs and flags. The CSV decodes table 2 for the standalone application. The strings file contains 179 nonempty entries, including tooltips, prompts, and command descriptions. |
| dialogs.json | Seven templates with child positions, styles, tab order as declared, and labels. A numeric control class is a Win32 ordinal (128 button, 129 edit, 130 static, 131 list box, 132 scrollbar, 133 combo box). Labels that are numbers can reference an image resource. |
| bitmaps/, tool-glyphs/, icons/, cursors/ | PNGs were exported at original dimensions. BMP files wrap the original DIB. ICO and CUR containers were reconstructed from the grouped resources. Cell coordinates, cursor hotspots, and group membership are in the matching JSON files. |
| palette.json | Two consecutive 14-entry RGB rows were read from the executable's .data section at raw file offset 0x37578. The bytes of each entry are red, green, blue, zero. Sample the final pixels under both full-color and palettized displays. |
| help-topics.md and help-art/ | The supplied WinHelp file was decoded to obtain 33 titled instructional topics, 23 context-text entries, and their inline pictures. The transcription preserves the instructions and removes navigation macros. The HLP references a companion contents file absent from the supplied ZIP. |
| checks/fixtures/ | Independently generated inputs and expected images. They establish BMP packing and simple mathematical operations. They are not original Paint exports. |

A resource template establishes its text and ordering on disk. Runtime options may hide, insert, disable, or relabel entries. For instance, the standalone File template contains a Send command and a recent-file placeholder, while the manual's File menu shows four paths and lacks Send. Capture each condition before wiring visibility.

## React95 icon comparison

The published **@react95/icons 2.13.0** package was inspected. Its PNG and SVG versions were compared separately to the decoded native icon images at 1×. The eight comparisons below returned zero differing visible pixels for each representation. SVGs were rasterized at intrinsic dimensions. Fully transparent pixels were ignored. The existing Win95GPT repository determines which installed version and imports to use.

| Resource group | React component | Exact variants checked | Use |
|---|---|---|---|
| 2 | Mspaint | 16x16_4 and 32x32_4 | Paint application icon |
| 3 | Mspaint3 | 16x16_4 and 32x32_4 | Bitmap document icon |
| 114 | Mspaint114 | 32x32_4 | Horizontal stretch illustration |
| 115 | Mspaint115 | 32x32_4 | Vertical stretch illustration |
| 116 | Mspaint116 | 32x32_4 | Horizontal skew illustration |
| 117 | Mspaint117 | 32x32_4 | Vertical skew illustration |

With the tested package, a named, per-icon import is available. Recheck the actual rendered component at device scale 1 after integration.

```tsx
import { Mspaint } from '@react95/icons/Mspaint';

<Mspaint variant="16x16_4" aria-hidden="true" />
```

Use the explicit size variant. Scaling the 32-pixel graphic down changes the 16-pixel design. The resource strip for the drawing buttons provides more precise artwork than a similarly named shell icon. The full sizes, tarball digest and comparison counts are in reference/react95-icons.json. [React95 project](https://github.com/React95/React95) · [Tested package tarball](https://registry.npmjs.org/@react95/icons/-/icons-2.13.0.tgz)

## External cross-checks

| Source | What it contributes |
|---|---|
| SURFCOM operating manual, printed pp. 8-15 to 8-18 (PDF pp. 178–181) | Screenshots show launching from Accessories, the standalone Paint window, Attributes, monochrome patterns, the Image and File menus, and Save As. Three embedded images are preserved locally: paint-window.png is PDF object 712, attributes.png is 718, monochrome.png is 723. These documented figures use a restricted palette whose exported white is #FEFEFE. Use them for geometry and content. Match colors and defaults against the executable and a native capture. [Manual, first illustrated page](https://inspectionengineering.com/wp-content/uploads/2017/10/Surfcom130-Operation-Manual1.pdf#page=178) |
| Microsoft KB Q186967 and Q251351, archived | Microsoft distinguishes PCX support in retail Windows 95 from its removal in OSR2.x and notes additional applications can install graphics filters. This resolves an apparent contradiction with the executable's leftover PCX label. [Q186967](https://www.betaarchive.com/wiki/index.php/Microsoft_KB_Archive/186967) · [Q251351](https://jeffpar.github.io/kbarchive/kb/251/Q251351/) |
| Microsoft KB Q130295, archived | Documents the 256-color palette issue and circumstances when Get Colors is unavailable. Test both image depth and display depth. [Q130295](https://jeffpar.github.io/kbarchive/kb/130/Q130295/) |
| Microsoft KB Q148494, archived | Identifies Pbrush.exe as the Windows 95 launcher forwarding arguments to Mspaint.exe. [Q148494](https://ftp.zx.net.nz/pub/archive/ftp.microsoft.com/MISC/KB/en-us/148/494.HTM) |
| Microsoft Win32 bitmap documentation | Describes BMP headers, color tables, data offsets, stride and direction. Consult it for encoding. Read input acceptance and conversion behavior from Paint. [Bitmap storage](https://learn.microsoft.com/en-us/windows/win32/gdi/bitmap-storage) · [Bitmap header](https://learn.microsoft.com/en-us/windows/win32/api/wingdi/ns-wingdi-bitmapinfoheader) |
| HelpDeco | The maintained C implementation was used to read the supplied HLP. This kit contains a readable transcription and original help art. Native WinHelp remains the behavioral reference. [HelpDeco](https://github.com/pmachapman/helpdeco) |
| JS Paint | Useful to study browser interaction techniques. Its maintainers document additions including unlimited, branched undo. OSR2 has a three-change limit. Do not adopt another app's menus, defaults, assets, or undo semantics by association. [JS Paint](https://github.com/1j01/jspaint) |
| Win95GPT | Public site HTML and linked application bundle were checked for host context. The inspected bundle contained Notepad window state, desktop display preferences, and tiled wallpaper definitions. This did not establish the current checkout's file APIs or exact icon version. The user's Win95GPT Project Assessment and ChatGPT 95 Master Build Prompt also identify a React/TypeScript desktop, existing window conventions and offline operation. [Win95GPT](https://win95gpt.com/) |

## Evidence still needed for a 1:1 claim

The supplied executable was inspected statically. A live OSR2 session was not captured during preparation of this kit. Highest-impact questions for native replay are the first-run dimensions and persisted options, runtime-selected menus and filters, tool-option geometry and brush masks, exact curve and ellipse rasterization, selection/clipboard commit order, monochrome dithering, installed fonts, and printer-dependent output. checks/coverage.csv gives these questions executable test steps. Use mismatches to refine the implementation, and record any browser capability boundary in the final report.
