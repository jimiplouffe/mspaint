"""Compare two lossless images at native size. Requires Python 3 and Pillow."""
import argparse
import json
from pathlib import Path
from struct import unpack_from
from PIL import Image, ImageChops


def describe(path):
    with Image.open(path) as src:
        image = src.convert('RGBA')
    if path.suffix.lower() != '.bmp':
        return image, None
    with path.open('rb') as file:
        header = file.read(54)
    if header[:2] != b'BM':
        raise ValueError(f'{path} has no BMP signature')
    dib = unpack_from('<I', header, 14)[0]
    if dib == 12:
        return image, {'dibBytes': dib, 'bpp': unpack_from('<H', header, 24)[0]}
    if dib < 40 or len(header) < 54:
        raise ValueError(f'Unrecognized BMP header in {path}')
    return image, {
        'dibBytes': dib, 'bpp': unpack_from('<H', header, 28)[0],
        'compression': unpack_from('<I', header, 30)[0],
        'signedHeight': unpack_from('<i', header, 22)[0],
        'pixelOffset': unpack_from('<I', header, 10)[0],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('reference', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('--diff', type=Path, help='Save a new PNG showing mismatches in magenta')
    parser.add_argument('--bpp', type=int, help='Require the candidate to be a BMP of this depth')
    args = parser.parse_args()
    a, meta_a = describe(args.reference)
    b, meta_b = describe(args.candidate)
    result = {'referenceSize': a.size, 'candidateSize': b.size, 'referenceBMP': meta_a, 'candidateBMP': meta_b}
    if a.size != b.size:
        print(json.dumps({**result, 'sameSize': False}, indent=2))
        return 1
    # Canonicalize hidden RGB only. A one-level channel difference at any
    # nonzero alpha still counts, even if a display composite would round it away.
    for image in (a, b):
        hidden = image.getchannel('A').point(lambda value: 255 if value == 0 else 0)
        image.paste((0, 0, 0, 0), (0, 0, *image.size), hidden)
    channels = ImageChops.difference(a, b).split()
    delta = channels[0]
    for channel in channels[1:]:
        delta = ImageChops.lighter(delta, channel)
    mask = delta.point(lambda n: 255 if n else 0)
    count = mask.histogram()[255]
    depth_pass = args.bpp is None or (meta_b is not None and meta_b['bpp'] == args.bpp)
    if args.diff:
        if args.diff.resolve() in {args.reference.resolve(), args.candidate.resolve()}:
            parser.error('Choose a diff path distinct from both input files.')
        visual = a.convert('RGB').point(lambda n: n // 3)
        visual.paste((255, 0, 255), (0, 0, *a.size), mask)
        visual.save(args.diff, format='PNG')
    print(json.dumps({**result, 'mismatchPixels': count, 'totalPixels': a.width * a.height,
                      'mismatchBoxLTRBExclusive': mask.getbbox(), 'candidateDepthMatches': depth_pass}, indent=2))
    return int(bool(count) or not depth_pass)


if __name__ == '__main__':
    raise SystemExit(main())
