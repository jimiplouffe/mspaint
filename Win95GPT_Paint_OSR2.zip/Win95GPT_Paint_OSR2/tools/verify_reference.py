"""Verify supplied file identity, PE resource payloads, and BMP fixture bytes (stdlib only)."""
from hashlib import sha256
from pathlib import Path
from struct import unpack_from
from zipfile import ZipFile
import json


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / 'reference'
TYPES = {1: 'cursor', 2: 'bitmap', 3: 'icon', 4: 'menu', 5: 'dialog', 6: 'strings',
         9: 'accelerators', 12: 'groupCursor', 14: 'groupIcon', 16: 'version'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_digest(data, expected, label):
    require(sha256(data).hexdigest() == expected, f'Digest mismatch for {label}')


def read_resources(exe):
    pe = unpack_from('<I', exe, 60)[0]
    require(exe[pe:pe + 4] == b'PE\x00\x00', 'Missing PE signature')
    section_count = unpack_from('<H', exe, pe + 6)[0]
    optional_size = unpack_from('<H', exe, pe + 20)[0]
    table = pe + 24 + optional_size
    for i in range(section_count):
        p = table + i * 40
        if exe[p:p + 8].rstrip(b'\x00') == b'.rsrc':
            rva, _, start = unpack_from('<III', exe, p + 12)
            break
    else:
        raise ValueError('No PE resource section')

    def visit(offset, path):
        directory = start + offset
        named, numbered = unpack_from('<HH', exe, directory + 12)
        require(named == 0, 'Unexpected named resource in this specific build')
        for i in range(numbered):
            key, target = unpack_from('<II', exe, directory + 16 + i * 8)
            if target & 0x80000000:
                yield from visit(target & 0x7fffffff, (*path, key))
            else:
                address, length = unpack_from('<II', exe, start + target)
                p = start + address - rva
                yield (*path, key), exe[p:p + length]
    return dict(visit(0, ()))


def main():
    build = json.loads((REFERENCE / 'build.json').read_text())
    source = REFERENCE / build['archive']
    verify_digest(source.read_bytes(), build['archiveSha256'], source.name)
    with ZipFile(source) as archive:
        files = {Path(name).name: archive.read(name) for name in archive.namelist()
                 if not name.endswith('/')}
    require(set(files) == set(build['files']), 'Unexpected archive members')
    for name, info in build['files'].items():
        verify_digest(files[name], info['sha256'], name)
    exe = files['mspaint.exe']
    payloads = read_resources(exe)
    index = json.loads((REFERENCE / 'resource-index.json').read_text())
    recorded = {(kind, row['id'], row['lang']): row for kind, rows in index.items() for row in rows}
    require(len(payloads) == len(recorded), 'Resource counts differ')
    for (number, identifier, language), data in payloads.items():
        key = (TYPES[number], identifier, language)
        verify_digest(data, recorded[key]['sha256'], str(key))
        if number == 2:
            bmp = (REFERENCE / 'bitmaps' / f'{identifier}.bmp').read_bytes()
            require(bmp[14:] == data, f'Bitmap {identifier} differs from original DIB')
    palette = json.loads((REFERENCE / 'palette.json').read_text())
    base = int(palette['fileOffsetHex'], 16)
    for i, color in enumerate(palette['top'] + palette['bottom']):
        require(bytes.fromhex(color[1:]) == exe[base+4*i:base+4*i+3], f'Swatch {i} differs')
    fixtures = ROOT / 'checks' / 'fixtures'
    fixtures_manifest = json.loads((fixtures / 'manifest.json').read_text())
    for name, info in fixtures_manifest.items():
        verify_digest((fixtures / name).read_bytes(), info['fileSha256'], name)
    print(f'Verified {len(files)} source files, {len(payloads)} resource payloads, '
          f'21 wrapped bitmap resources, 28 color entries, and {len(fixtures_manifest)} fixture files.')


if __name__ == '__main__':
    main()
