# Paint Help

Reference transcription of the supplied English MSPAINT.HLP. Paragraphs and inline tool pictures are preserved. Topic order is the Help file order. Compiler navigation macros are omitted. Open the supplied HLP in WinHelp for native navigation.

## Using black and white instead of color

To use black and white instead of color

1 On the Image menu, click Attributes.

2 Click Black and White.

Caution

![tool](help-art/bm0.png) Once you have changed a color picture to black and white, you cannot change it back to color. If you change back to color, only new work will be in color.

## Changing the size of your picture

To change the size of your picture

1 On the Image menu, click Attributes.

2 Click the unit of measurement you want to use for the width and height.

3 Type the width and height.

Notes

![tool](help-art/bm0.png) Your current picture will be resized. If your current picture is bigger than the new size, it is cut from the right side and bottom to fit within the smaller area.

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Showing or hiding the tool box

To show or hide the tool box

![tool](help-art/bm1.png) On the View menu, click Tool Box.

A check mark appears when the tool box is visible.

Tip

![tool](help-art/bm0.png) You can drag the tool box to any location in the window.

## Showing or hiding the color box

To show or hide the color box

![tool](help-art/bm1.png) On the View menu, click Color Box.

A check mark appears when the color box is visible.

Tip

![tool](help-art/bm0.png) You can drag the color box to any location in the window.

## Inverting colors

To invert all the colors in a picture

![tool](help-art/bm1.png) On the Image menu, click Invert Colors.

Note

![tool](help-art/bm0.png) Each color is replaced by its color complement. For example, white becomes black, and red becomes blue.

## Drawing a straight line

To draw a straight line

1 Click ![tool](help-art/bm2.png) in the tool box.

![tool](help-art/bm3.png) To choose the width the line will be, click a line width from the bottom of the tool box.

![tool](help-art/bm3.png) To choose the color the line will be, click a color.

2 To draw the line, drag the mouse pointer.

Tips

![tool](help-art/bm0.png) Use the left mouse button to draw with the foreground color or the right mouse button to draw with the background color.

![tool](help-art/bm0.png) To draw a perfectly horizontal, vertical, or 45-degree diagonal line, press and hold down SHIFT while dragging the mouse pointer.

## Drawing a curve

To draw a curve

1 Click ![tool](help-art/bm4.png) in the tool box.

![tool](help-art/bm3.png) To choose the width the curve will be, click a line width at the bottom of the tool box.

![tool](help-art/bm3.png) To choose the color the curve will be, click a color.

2 Draw a straight line by dragging the mouse pointer.

3 Click where you want one arc of the curve to be, and then drag the mouse pointer to adjust the curve.

Each curve must have at least one arc but no more than two. Repeat this step for a second arc.

Tips

![tool](help-art/bm0.png) Use the left mouse button to draw with the foreground color or the right mouse button to draw with the background color.

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Drawing a free-form line

To draw a free-form line

1 Click ![tool](help-art/bm5.png) in the tool box, and then click a color from the color box.

2 To draw the line, drag the mouse pointer.

Tip

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Drawing a rectangle or square

To draw a rectangle or square

1 Click ![tool](help-art/bm6.png) in the tool box to create a square-cornered shape, or click ![tool](help-art/bm7.png) to create a round-cornered shape.

2 Click a color from the color box for the shape's outline.

3 To fill the shape with color, click a color by using the right mouse button, and then click a fill style from the bottom of the tool box.

4 To draw a rectangle, drag the mouse pointer diagonally in the direction you want.

To draw a square, press and hold down SHIFT while dragging the mouse pointer.

## Drawing a polygon

To draw a polygon

1 Click ![tool](help-art/bm8.png) in the tool box, and then click a color for the polygon outline.

2 To create a colored fill, click a color by using the right mouse button, and then click a fill style from the bottom of the tool box.

3 To draw the polygon, drag the mouse pointer and click at each corner. Double-click when you're done.

To use only 45- and 90-degree angles, press and hold down SHIFT while dragging the mouse pointer.

Tip

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Drawing an ellipse or circle

To draw an ellipse or circle

1 Click ![tool](help-art/bm9.png) in the tool box.

2 Click a color from the color box for the shape's outline.

3 To fill the shape, click a color by using the right mouse button, and then click a fill style from the bottom of the tool box.

4 To draw an ellipse, drag the mouse pointer diagonally.

To draw a perfect circle, press and hold down SHIFT while dragging the mouse pointer.

Tip

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Painting with a brush

To paint with a brush

1 Click ![tool](help-art/bm10.png) in the tool box, and then choose a brush shape from the bottom of the tool box.

2 Click a color from the color box.

3 To paint, drag the mouse pointer.

Tip

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Filling an area with color

To fill an area or object with color

1 Click ![tool](help-art/bm11.png) in the tool box, and then click a color from the color box.

2 Click the area or object you want to fill:

![tool](help-art/bm3.png) To fill with the foreground color, click the area with the left mouse button.

![tool](help-art/bm3.png) To fill with the background color, click the area with the right mouse button.

Tips

![tool](help-art/bm0.png) If the shape being filled has any breaks in its border, the filling color leaks through to the rest of the drawing area. To find and close the opening, click View, point to Zoom, and then click Large Size or Custom.

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Typing and formatting text

To type and format text

1 Click ![tool](help-art/bm12.png) in the tool box.

2 Create a text frame by dragging the mouse pointer diagonally, and then click the font, size, and style you want.

3 Click inside the text frame, and then type the text.

![tool](help-art/bm3.png) Move or enlarge the text frame as needed.

![tool](help-art/bm3.png) To change the color of the text, click a color in the color box.

![tool](help-art/bm3.png) To insert the text on a colored background, click ![tool](help-art/bm13.png) on the tool box, and then click a color with the right mouse button to change the background color.

4 To insert the text into the picture, click outside the text frame.

Tips

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

![tool](help-art/bm0.png) You can only paste text when the text tool is selected. You cannot paste graphics when the text tool is selected.

![tool](help-art/bm0.png) You can enter text into a picture only in normal view.

![tool](help-art/bm0.png) If the text toolbar obscures part of the Paint menu, you can drag it anywhere on the window.

## Erasing a small area

To erase a small area

1 Click ![tool](help-art/bm14.png) in the tool box.

![tool](help-art/bm3.png) To use a smaller or larger eraser, click a shape at the bottom of the tool box.

![tool](help-art/bm3.png) The selected background color shows what color the eraser will leave behind. To change the background color, click a color by using the right mouse button.

2 Drag the mouse pointer over the area you want to erase.

Tips

![tool](help-art/bm0.png) To undo a change, click Edit, and then click Undo. You can undo up to three changes.

![tool](help-art/bm0.png) To change a specific color (and nothing else), change the foreground color to the color you want to erase and the background color to the color you want to replace it with. Click the eraser, and then use the right mouse button to change the color.

## Erasing a large area

To erase a large area

1 Click ![tool](help-art/bm15.png) or ![tool](help-art/bm16.png) in the tool box, and then drag the mouse pointer to select the area you want to erase. The current background color will be used to fill the cleared area.

2 To choose a different background color, click a color in the color box with the right mouse button.

3 On the Edit menu, click Clear Selection.

## Undoing changes

To undo changes

![tool](help-art/bm1.png) On the Edit menu, click Undo.

To undo previous changes, click Undo again.

Note

![tool](help-art/bm0.png) You can undo up to three changes.

## Creating an airbrush effect

To create an airbrush effect

1 Click ![tool](help-art/bm17.png) in the tool box.

![tool](help-art/bm3.png) To change the size of the spray area, click a size from the bottom of the tool box.

![tool](help-art/bm3.png) To choose the spray color, click a color.

2 To spray, drag the mouse pointer. Use the left mouse button to spray with the foreground color, or use the right mouse button to spray with the background color.

Tip

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Specifying transparent or opaque drawing

To specify transparent or opaque drawing

![tool](help-art/bm1.png) To choose transparent drawing, click the Options menu, and then make sure Draw Opaque is not checked.

To choose opaque drawing, click the Options menu, and then make sure Draw Opaque is checked.

## Flipping or rotating a picture or object

To flip or rotate a picture or object

1 Click ![tool](help-art/bm15.png) or ![tool](help-art/bm16.png) in the tool box, and then drag a box around the object or area you want to flip or rotate.

![tool](help-art/bm3.png) Click ![tool](help-art/bm13.png) below the tool box to flip or rotate opaquely.

![tool](help-art/bm3.png) Click ![tool](help-art/bm18.png) below the tool box to flip or rotate transparently.

2 On the Image menu, click Flip/Rotate.

3 Click the option you want.

Tip

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Stretching or skewing an item

To stretch or skew an item

1 Click ![tool](help-art/bm15.png) or ![tool](help-art/bm16.png) in the tool box, and then drag a box around the item you want to change.

2 On the Image menu, click Stretch/Skew.

3 Click the stretching or skewing option you want, and then enter the amount.

![tool](help-art/bm3.png) Click ![tool](help-art/bm13.png) below the tool box to stretch or skew opaquely.

![tool](help-art/bm3.png) Click ![tool](help-art/bm18.png) below the tool box to stretch or skew transparently.

Tip

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Printing a picture

To print a picture

![tool](help-art/bm1.png) On the File menu, click Print.

Tips

![tool](help-art/bm0.png) To see how the printed picture will look before you print, click the File menu, and then click Print Preview.

![tool](help-art/bm0.png) To set margins or change orientation, click the File menu, and then click Page Setup.

## Zooming in or out

To zoom in or out of a picture

![tool](help-art/bm1.png) On the View menu, point to Zoom, and then click Normal Size, Large Size, or Custom.

Note

![tool](help-art/bm0.png) You can enter text into a picture only in normal view.

## Enlarging the size of the viewing area

To enlarge the size of the viewing area

![tool](help-art/bm1.png) To display only the picture, click the View menu, and then click View Bitmap.

You cannot make changes to a picture in this view. To return to your former view, click anywhere in the picture.

Tip

![tool](help-art/bm0.png) You can hide the Tool Box, Color Box, or Status Bar by clicking the View menu and then removing the check mark for each item you don't want displayed.

## Displaying grid lines

To display grid lines

1 On the View menu, point to Zoom, and then click Custom.

2 Click a Zoom To size of 400%, 600%, or 800%, and then click OK.

3 On the View menu, point to Zoom, and then click Show Grid.

Tip

![tool](help-art/bm0.png) To get rid of the grid lines, return to normal view, or repeat step 3 to remove the check mark.

## Changing the color of an existing line

To change the color of an existing line

1 Click ![tool](help-art/bm11.png) in the tool box.

2 Click a different color in the color box.

3 Position the paint cursor so that it is touching the line, and then click.

Tips

![tool](help-art/bm0.png) To make sure you only change the line color and not the surrounding area, zoom the picture to a larger size.

![tool](help-art/bm0.png) If the line is part of a shape, any connecting vertical and horizontal lines will also change to the new color.

## Copying color from one area or object to another

To copy color from one area or object to another

1 Click ![tool](help-art/bm19.png) in the tool box.

2 Click the object whose color you want to copy.

3 Click the object or area where you want the color.

Tip

![tool](help-art/bm0.png) To use a color as a background color or to erase with a color that isn't in the color box, click the color in your picture with the right mouse button.

## Creating custom colors

To create custom colors

1 In the color box, click the color you want to change.

2 On the Options menu, click Edit Colors.

3 Click Define Custom Colors, and then enter new values in either the RGB (red, green, blue) or HLS (hue, saturation, and luminescence) color models.

4 Click Add to Custom Colors.

Tips

![tool](help-art/bm0.png) To save your custom colors, click the Options menu, and then click Save Colors.

![tool](help-art/bm0.png) To use your saved colors, click Get Colors.

![tool](help-art/bm0.png) For Help on an item, click ![tool](help-art/bm20.png) at the top of the dialog box, and then click the item.

## Selecting part of a picture

To select part of a picture

![tool](help-art/bm1.png) To select a rectangular area, click ![tool](help-art/bm15.png) in the tool box, and then drag the cursor diagonally across the area.

To select an irregularly shaped area, click ![tool](help-art/bm16.png) in the tool box, and then drag the cursor around the area.

Tip

![tool](help-art/bm0.png) To remove the selection box, click outside the box.

## Copying part of a picture

To copy part of a picture

1 Select the area you want to copy by clicking ![tool](help-art/bm15.png) or ![tool](help-art/bm16.png) in the tool box and then dragging the cursor to define the area.

![tool](help-art/bm3.png) Click ![tool](help-art/bm13.png) to insert opaquely.

![tool](help-art/bm3.png) Click ![tool](help-art/bm18.png) to insert transparently.

2 On the Edit menu, click Copy.

3 On the Edit menu, click Paste.

4 Drag the selection where you want it.

5 To remove the selection box, click outside it.

Tips

![tool](help-art/bm0.png) To paste multiple copies of an object, press and hold down CTRL while you drag the pasted object to a new location. Repeat as needed.

![tool](help-art/bm0.png) You cannot paste graphics when the text tool is selected.

![tool](help-art/bm0.png) To undo a change, click Edit and then click Undo. You can undo up to three changes.

## Saving part of a picture

To save part of a picture into another bitmap file

1 Select an area you want to save by clicking ![tool](help-art/bm15.png) or ![tool](help-art/bm16.png) in the tool box and then dragging the cursor to define the area.

2 On the Edit menu, click Copy To.

3 Specify a file name and location.

## Inserting a bitmap into the current picture

To insert a bitmap into the current picture

1 Select an area to put the picture in by clicking ![tool](help-art/bm15.png) in the tool box and then dragging the cursor to define the area.

2 On the Edit menu, click Paste From.

3 Specify the name of the bitmap file you want to insert.

4 Drag the selection where you want it, and then click outside the selection.

## Using a picture as the desktop background

To use a picture as the desktop background

![tool](help-art/bm1.png) To cover the screen with repetitions of your bitmap, click the File menu, and then click Set As Wallpaper (Tiled).

To put your bitmap in the center of your screen, click the File menu, and then click Set As Wallpaper (Centered).

Note

![tool](help-art/bm0.png) You must save a picture before you can use it as wallpaper.

## Context help

**241SHX7**

Specifies that the existing picture will show through your selection, and the background color of the selection will not be displayed.

**3MM49K7**

Specifies that your selection will cover the existing picture, using the foreground and background colors of the selected object.

**18IJ05R**

The drawing color is used for lines, borders of shapes, and text.

**18IEVQX**

The background color is used to fill the inside of enclosed shapes and the background of text frames. It also appears when you use the eraser.

**JP.RLA**

Click Help Topics for a list of Help topics.

**I77FNK**

Displays the current magnification.

**FFH4OT**

Help is available for each item in this group. Click ![tool](help-art/bm20.png) at the top of the dialog box, and then click the specific item you want information about.

**20TTVDK**

Shows which magnifications you can specify. You can specify from normal (100%) to eight times normal (800%) magnification.

**14YTVVG**

Flips the selected area or your entire picture horizontally.

**1N677QP**

Flips the selected area or your entire picture vertically.

**1_YNBVS**

Rotates the selected area or your entire picture at the angle you specify.

**5VSS5O**

Stretches the selected area or your entire picture horizontally by the percentage you specify. Positive numbers increase the size, negative numbers decrease the size.

**423CZ4F**

Stretches the selected area or your entire picture vertically by the percentage you specify. Positive numbers increase the size, negative numbers decrease the size.

**2_6DZHV**

Skews the selected area vertically by the number of degrees you specify. Positive numbers skew in the same direction of the arrow, negative numbers skew in the opposite direction of the arrow.

**311NI9P**

Skews the selected area horizontally by the number of degrees you specify. Positive numbers skew in the same direction of the arrow, negative numbers skew in the opposite direction of the arrow.

**K1745I**

Specifies the width of the picture in exact units.

**TUJ9XN**

Specifies the height of the picture in exact units.

**7G9LQ3**

Specifies that inches are used to measure the height and width of your picture.

**DNIRZF**

Specifies that centimeters are used to measure the height and width of your picture.

**1VHI9O5**

Specifies that pixels are used to measure the height and width of your picture.

**2.SGO34**

Specifies that new files should use the default size and colors.

**9P5V7B**

Specifies to draw in black and white, and changes all existing objects in the picture to black and white. You cannot change an object from black and white back to color.

**50OYQD**

Specifies to draw in color, but does not change any existing black and white objects to color.

