# Reference capture and parity testing

## Set up a repeatable comparison

1. Start an English Windows 95 OSR2 VM or machine. Extract reference/original-osr2-en.zip into its own reference directory. Launch that copy of MSPAINT.EXE and confirm its SHA-256 against reference/build.json on the host. Use the existing OS system files. Record OS version, EXE hash, display size/depth, system font/small-font settings, available printer, installed input filters, and profile freshness. Save a clean snapshot when the environment supports it.
2. A suggested baseline is 800×600, small fonts at 96 DPI, default classic scheme, and a high-color display. Add a 256-color run for palette behavior. Match the exact native window bounds in Win95GPT, browser zoom at 100%, and device scale factor 1 for pixel comparisons. Disable host scanlines, pointer trails and compositor effects for this profile. A second run at DPR 2 checks scaling. Declare the actual native settings with the evidence.
3. Use lossless guest-framebuffer PNGs. Capture a fixed restored window, maximized window, each open menu and option bank, each tool's cursor on two backgrounds, four main image dialogs, color chooser, file dialogs, text toolbar, thumbnail, print preview, help and dirty prompts. Capture the held/hover/disabled/checked/focus states at the same timing. A screenshot with app focus lost will have different chrome. For cursor/animation probes, include the pointer or capture successive frames intentionally.
4. Use logical image coordinates measured from the top-left document pixel, with zero-based (x,y). Replay the same buttons, press/release ordering, modifiers, cancellation, and selected colors on each side. Record the input trace and zoom. Use fixture BMPs for repeatability. For deterministic drawing compare the **saved/reopened document** as well as the UI; a matching screenshot can conceal a flipped, resampled, or incorrectly encoded file.
5. Fill checks/coverage.csv with the reference observation, branch/build identifier, evidence path, status and discrepancy. For each native capture, preserve original image dimensions and use a meaningful name such as T11-curve-after-second-bend-native.png. Capture the same state in the build and retain mismatch imagery until resolved. Cases spanning several settings need separate evidence for each setting.

## Fast regression run

From the kit root, run the reference integrity check with Python 3. The image comparisons also require Pillow.

```sh
python tools/verify_reference.py
python tools/compare_pixels.py checks/fixtures/odd-24bpp.png checks/fixtures/odd-24bpp.bmp --bpp 24
python tools/compare_pixels.py checks/fixtures/expected-invert.png candidate-inverted.bmp --bpp 24 --diff invert-diff.png
python tools/compare_pixels.py guest-window.png web-window.png --diff window-diff.png
```

The first two commands are kit self-checks. Supply your own outputs for the last two comparisons. Exit 0 means exact visible-pixel equality and the requested candidate BMP depth. Exit 1 means size, depth, or pixel mismatch. The tool reports the mismatch count, bounding box and basic BMP fields. It ignores RGB under fully transparent pixels. Inspect and compare BMP tables, compression and headers separately. Use raw hashes only where exact file serialization is part of the case.

| Inputs or expected image | Use |
|---|---|
| odd-1bpp.bmp | 13×9, white at palette index 0, black at 1. Exposes bit order, inverted palette assumptions and alignment. |
| odd-4bpp.bmp | 13×9, a custom 16-entry palette. Tests nibble order, odd trailing nibble and row padding. |
| odd-8bpp.bmp | 13×9, a custom 256-entry palette. Tests palette lookup and padded scanlines. |
| odd-24bpp.bmp and odd-24bpp.png | Identical rendered RGB. An asymmetric 13×9 pattern tests BGR order, vertical orientation, padding and transforms. |
| expected-invert.png, expected-flip-horizontal.png, expected-flip-vertical.png, expected-rotate-180.png | Corresponding mathematical transforms of the 24-bit fixture. Start each operation by reopening the source with no selection. |
| blank-64x48.bmp, expected-four-marks.png, expected-three-undo.png | Explicitly select black Pencil. Click (1,1), (3,1), (5,1), (7,1), releasing after each down. After three undos only the first dot remains. Save or capture each checkpoint without introducing an intermediate save into the undo sequence being measured. |
| fixtures/manifest.json | Dimensions and hashes for each file. RGB hashes cover top-down row-major R,G,B bytes, with no alpha channel. |

## How to judge results

- **Core deterministic drawing:** zero differing document pixels for each native replay. A one-pixel error at the edge of a curve or selection is a failure for that case. Use lossless saved bitmaps when possible. Some palette/encoding differences need separate checks even when RGB matches.
- **Screen fidelity:** compare same-size images at native scale. For a mismatch, isolate chrome, tool art, canvas, status text, or a specific dialog. Measure the width, font, baseline or bevel that differs. Record any fixed masks for pointer or blinking caret explicitly. Keep an unmasked comparison as well.
- **Airbrush:** gather multiple equal-duration presses for each size and plot occupied bounds, deposit count/distribution, and growth over time. Record native variance. Use a seeded test implementation only for internal regressions. A matching PRNG seed in the web implementation alone cannot establish native parity.
- **Text/print:** record font name, installed font file, size/style, smoothing, printer driver, printable area and margins. Compare glyph masks and page layout in matched profiles. Attribute a remaining difference to a specific missing font or output capability with evidence.
- **History and errors:** examine the original command's enablement and document state before and after accept, reject, cancel, and failed save/open. Verify file bytes after reopening. A visually correct dialog that drops edits or commits on Cancel fails.
- **Completion report:** summarize by scenario ID, native evidence, web evidence, metrics and status. Use Passed, Failed, Unverified or Host adaptation. A native capture or a witnessed replay of both builds is required for a runtime pass. Static resource matches and independent fixture matches should be reported separately. If a feature requires a missing desktop service, record the reference state and actual functioning fallback or the remaining gap.
