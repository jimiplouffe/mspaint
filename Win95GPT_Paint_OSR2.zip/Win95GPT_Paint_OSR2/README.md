# Win95GPT · Windows 95 Paint rebuild kit

**Give the ZIP to the coding agent and paste Win95GPT_Paint_Agent_Prompt.md into its session.** The kit is self-contained for implementation. A running English Windows 95 OSR2 system provides the final behavior and screenshot comparisons.

| Start with | What it answers |
|---|---|
| Win95GPT_Paint_Agent_Prompt.md | What to build, where to integrate it, and what counts as delivered. |
| SPEC.md | How the shell, menus, drawing tools, selections, file operations, and dialogs fit together. |
| RESEARCH.md | Which facts came from the supplied build, which came from external references, and which need observation. |
| reference/tool-and-color-guide.png | Which glyph occupies each toolbox slot and which colors belong in each row. |
| reference/menus.json, shortcuts.csv, dialogs.json, strings.json | Exact English labels, mnemonic positions, resource IDs, key bindings, dialog units, control order, and status text. |
| reference/help-topics.md | Searchable drawing and editing instructions from the supplied Paint Help. |
| reference/period/ | Three period reference images with their original raster dimensions. Attribution and measurement notes are in RESEARCH.md. |
| checks/PARITY.md and checks/coverage.csv | A reproducible capture procedure and a checklist for the host, UI, all tools, and saved documents. |
| checks/fixtures/ and tools/compare_pixels.py | Ready-to-open BMPs, independently generated expected images, and a lossless pixel comparison utility. |
| reference/original-osr2-en.zip and reference/build.json | The unchanged attachment plus hashes of the archive and each of its six files. |

The 1:1 target applies to a defined OSR2 display, font, printer, and shell profile. The kit verifies the static resources and icon matches. Native replay, the project implementation, and its parity report are the coding agent's deliverables.
